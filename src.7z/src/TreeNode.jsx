import React, { useState } from 'react';

// Компонент для отображения узла дерева
const TreeNode = ({ node, onAdd, onDelete }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [newChildTitle, setNewChildTitle] = useState('');
  //Раскрыть-скрыть список
    const toggleOpen = () => setIsOpen(!isOpen);
  
    const handleAddChild = () => {
      if (newChildTitle) {
        onAdd(node.title, newChildTitle);
        setNewChildTitle('');
      }
    };
  
    return (
      <div style={{ marginLeft: '20px' }}>
        <div>
          <span onClick={toggleOpen} style={{ cursor: 'pointer' }}>
             {isOpen ? '-' : '+'} {node.title}
          </span>
          <button onClick={() => onDelete(node.title)}>Удалить</button>
        </div>
        {isOpen && (
          <div>
            <input
              type="text"
              value={newChildTitle}
              onChange={(e) => setNewChildTitle(e.target.value)}
              placeholder="Добавить дочерний элемент"
            />
            <button onClick={handleAddChild}>Добавить</button>
            {node.children && node.children.map((child, index) => (
              <TreeNode
                key={index}
                node={child}
                onAdd={onAdd}
                onDelete={onDelete}
              />
            ))}
          </div>
        )}
      </div>
    );
  };

  export default TreeNode