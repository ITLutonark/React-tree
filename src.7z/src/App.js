import './App.css';
import Tree from './Tree';

function App() {
  return (
<Tree />
  );
}

export default App;
